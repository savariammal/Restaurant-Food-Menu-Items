export class Item {
    constructor(
        public itemname:string, 
        public itemtype:string, 
        public itemprice:number, 
        public id?:number
        )
    {

    }
}
